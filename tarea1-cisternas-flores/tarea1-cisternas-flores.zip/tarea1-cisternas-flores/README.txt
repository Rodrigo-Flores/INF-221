La entrega cuenta con tres archivos.
1.- fuerza_bruta.py
    Solucion para Problema 1

    Indicaciones de uso:
        Comando: python fuerza_bruta.py < ejemplo.txt

2.- memoizacion.py
    Solucion para Problema 2

    Indicaciones de uso:
        Comando: python memoizacion.py < ejemplo.txt

3.- procesador_entrada.py
    Procesará la entreda mediante un archivo .txt para la revisión.

    Observaciones:
        Contiene una dependencia con el paque built-in de Python, sys.

        No se utiliza directamente, ya viene hecha la integración en las soluciones.

Observaciones
    El formato de entrada de los datos es tal y como se ve en el archivo "ejemplo.txt"

    El codigo actual fuciona sin problemas